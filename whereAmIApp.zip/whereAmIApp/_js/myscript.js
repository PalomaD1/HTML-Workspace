



$(document).ready(function() {

	var x = document.getElementById("lat");
		var y=document.getElementById("lng");
		var z=document.getElementById("acc");

	$('button').on('click',function(){
		//setup Google map using current location 
		//declare variables
		
		

		$('#myLocation').show();//show the mylocation div

		getLocation();
		

		
	});//end the onclick method

	function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showErr);
    }else{
    	console.log("Error");
    }


}

function showErr() {
	x.innerHTML = "Geolocation is not supported by this browser.";
	y.innerHTML = "Geolocation is not supported by this browser.";
	z.innerHTML = "Geolocation is not supported by this browser.";

	}

function showPosition(position) {
    x.innerHTML = position.coords.latitude;
    y.innerHTML= position.coords.longitude;
    z.innerHTML= position.coords.accuracy + "m";
   
	var mapProp = {
			center: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
			zoom:15
		};
		var map = new google.maps.Map($('#map_canvas').get(0),mapProp);

		var marker=new google.maps.Marker({
			position:new google.maps.LatLng(position.coords.latitude, position.coords.longitude)
		});
		marker.setMap(map);
	
}



});