$(document).ready(function() {
	var resultsDiv = $('.results'); 
	$('button').click(function(){
		 $(resultsDiv).slideDown(); //slidedown function 
		$.ajax({
			url: 'resources/data/data.xml',  //data to load from the server
			type: 'GET',                     //type of request, could be GET or POST
			dataType: 'xml',                 //data type (html, xml, jason, etc.)
			success:parseXML                 //function to call once the data is received 
		});		
	});

//change the text color of each choice on mouse over and mouse out
	$(document).on('mouseover', 'p', function(){

	
	// $(this).find("[correct='true']").css('color', 'green');
	
        $(this).css('color', 'red');
    
        } )
	
$(document).on('mouseleave', 'p', function(){
        $(this).css('color', 'black');
        } )
//change the text color of each choice on mouse over and mouse out
/*	$(document).on('mouseover', 'p', function(){
        $(this).css('background-color', 'green');
        } )
$(document).on('mouseleave', 'p', function(){
        $(this).css('color', 'white');
        } ) */



	function parseXML(data) { //data variable represents the data received from the server. You can give it any name
		console.log(data); //compare the console output to the xml file(resources/data/data.xml).. the xml is represented using JavaScript object
		resultsDiv.empty();

		$(data).find('quiz-title').each(function(){
          resultsDiv.append('<h1>' + $(data).find('quiz-title').text() + '</h1>');
		   //resultsDiv.append('<h2>' + $(data).find('quiz-description').text() + '</h2>');
		})
		
		$(data).find('quiz-description').each(function(){
          resultsDiv.append('<h2>' + $(data).find('quiz-description').text() + '</h2>');
		   //resultsDiv.append('<h2>' + $(data).find('quiz-description').text() + '</h2>');
		})
		  var i=0; //function is called for each function, variable must be declared outside the method
		
		$(data).find('question').each(function(){ //loop on all the books 
			
         
        

		 //   var quizDescrip=$(this).find('quiz-description').text();
			var quizQuestion=$(this).find('quiz-question').text();
		    var choicestext=" "; 
		    var choicepara=$(" ");
			$(this).find('choice').each(function() {
				var choice= $(this).text();
				var correct = $(this).attr("correct");
				

			   choicepara.append( "<p>"+ choice+"</p>");
				choicepara.data("datacorr",correct);
            choicestext = choicestext+'<p>' + choice +'</p>'; 
			});
			
			i++; //increment counter
			$('<h3></h3>').text("Q"+i + "." + quizQuestion).appendTo(resultsDiv);	
			

		
			resultsDiv.append(choicestext); 
	

			resultsDiv.append('<hr>');//adds a line break
            
		
		});
	}

});