var Global = {};



$(document).one("pagecreate",function(){

  Global.lat = "";
  Global.lng = "";
  Global.city = "";
  Global.search ="";

   function getData(){
      navigator.geolocation.getCurrentPosition(showPosition, showErr);
      function showErr() {
        alert("Geolocation is not supported by this browser.");
      }
      function showPosition(position) {
        Global.lat =  position.coords.latitude;
        Global.lng =  position.coords.longitude;
        updateData(Global.lat,Global.lng);
      }
    }


    function updateData(lat,lng) {
      $.ajax({
          url: "https://api.darksky.net/forecast/46e617b0198645d3eea0c3396a119a31/"+lat+","+lng,
          dataType: 'jsonp',
          success: getWeather
      });
      function getWeather(data){
        console.log(data);
        $('#currentweatherlabel').empty();
        var currTemp=Math.ceil((data.currently.temperature-32)*0.5556);
        $('#currentweatherlabel').append("Current Weather: "+currTemp+"&#8451;");
      }
    }


  getData();

  $('#currLoc').on('click',function() {
    getData();
  });

  $('#search').on('click',function() {
    Global.search = $("#searchcitytext").val();
    console.log(Global.search);
    $.ajax({
          url: "https://maps.googleapis.com/maps/api/geocode/json?address="+Global.search,
          dataType: 'JSON',
          success: function(position){
            console.log(position);
          Global.lat =  position.results[0].geometry.location.lat;
          Global.lng =  position.results[0].geometry.location.lng;
          updateData(Global.lat,Global.lng);
        },
     error: function(jqXHR, exception) {
      var msg = '';
        if (jqXHR.status === 0) {
            msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
            msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
            msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
            msg = 'Requested JSON parse failed, API not found.';
        } else if (exception === 'timeout') {
            msg = 'Time out error.';
        } else if (exception === 'abort') {
            msg = 'Ajax request aborted.';
        } else {
            msg = 'API not found.\n' + jqXHR.responseText;
        }
        alert(msg);
   
   }
    });
  });

    $('select.city').on('change', function() {
      Global.city = $("#listOfCities option:selected").text();
      if(Global.city){
        $.ajax({
            url: "https://maps.googleapis.com/maps/api/geocode/json?address="+Global.city,
            dataType: 'JSON',
            success: function(position){
            Global.lat =  position.results[0].geometry.location.lat;
            Global.lng =  position.results[0].geometry.location.lng;
            updateData(Global.lat,Global.lng);
            }
        });
      }
    });

//dark sky api used
//button event handler for geolocation
  var localStorageArray=[];
var mainList=$('#searchCity');
var lat;
  var lng;
 var sugList = $("#suggestions");

var date=new Date();
var time = date.getHours();
var hours =[];
var temp =[];
var weekly=[];
var futtime=time;
for(var i=0;i<24;i++)
{
    hours.push(futtime);
    if(futtime<24)
    futtime++;
    else
    {
        futtime=0;
    }
}

loadData();

  function loadData(){
    if(localStorage.recentSearches){
      localStorageArray = JSON.parse(localStorage.recentSearches);
      $.each(localStorageArray,function(index,itm){
       searchCity.prepend("<option value=''>" + itm + "</option>"); 
      });

    }
  }

   $("#searchField").on("input", function(e) {
        var text = $(this).val();
        if(text.length < 1) {
            sugList.html("");
            sugList.listview("refresh");
        } else {
            $.get("service.cfc?method=getSuggestions", {search:text}, function(res,code) {
                var str = "";
                for(var i=0, len=res.length; i<len; i++) {
                    str += "<li>"+res[i]+"</li>";
                }
                sugList.html(str);
                sugList.listview("refresh");
                console.dir(res);
            },"cities.json");
        }
    });


var inputValue = $('#searchcitytext').val();
localStorageArray.push(inputValue);
localStorage.searchCity1=JSON.stringify(localStorageArray);
console.log(hours);
console.log(temp);


function displayChart() {

var ctx = document.getElementById("todaysweatherchart").getContext('2d');
  var myChart = new Chart(ctx, {
      type: 'line',
      data: {
          labels:hours,
          datasets: [{
              data:temp,
              borderWidth: 1
          }]
      },
      options : {
        legend: {
         display: false,
      labels: {
        display: false
      }

      },
      scales: {
        yAxes: [{
          scaleLabel: {
            display: true,
            labelString: 'Temperature in Celsius'
          }
        }],
        xAxes: [{
          scaleLabel: {
            display: true,
            labelString: 'Hours'
          }
        }],
      }
    }
  });


    var ctx = document.getElementById("weeklyweatherchart").getContext('2d');
  var myChart = new Chart(ctx, {
      type: 'bar',
      data: {
          labels: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday","Sunday"],
          datasets: [{
              data: weekly,
              borderWidth: 1
          }]
      },
     options : {
      legend: {
         display: false,
      labels: {
        display: false
      }

      },
      scales: {
        yAxes: [{
          scaleLabel: {
            display: true,
            labelString: 'Temperature in Celsius'
          }
        }],
        xAxes: [{
          scaleLabel: {
            display: true,
            labelString: 'Days'
          }
        }],
      }
    }
  });


}

$.ajax({
    url: "https://api.darksky.net/forecast/46e617b0198645d3eea0c3396a119a31/37.8267,-122.4233",
    dataType: 'jsonp',
    success: function(results){
        $.each(results.hourly.data,function(index,value){
        if(index<24){

           temp.push(((this).temperature-32)*0.5556);
        }
        });
        $.each(results.daily.data,function(index,value){
        

           weekly.push(((this).temperatureMax-32)*0.5556);
        
        });
        var currTemp=Math.ceil((results.currently.temperature-32)*0.5556);
        console.log(currTemp);
        
        $('#currentweatherlabel').append(currTemp+"&#8451;");
        displayChart();
    },
     error: function(jqXHR, exception) {
      var msg = '';
        if (jqXHR.status === 0) {
            msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
            msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
            msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
            msg = 'Requested JSON parse failed, API not found.';
        } else if (exception === 'timeout') {
            msg = 'Time out error.';
        } else if (exception === 'abort') {
            msg = 'Ajax request aborted.';
        } else {
            msg = 'API not found.\n' + jqXHR.responseText;
        }
        alert(msg);
   
   }

});


//button event handler for geolocation


$.get('cities.json').done(function(data){
  $.each(data, function(key, value) { 
    console.log(value); //this passes the title and answers to the console
      $('#searchCity').append('<option>'+value+'<option>');   
  });
});

      $("#btnLocation").click(function() {
        getLocation();
    });

    function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showErr);
    }else{
        console.log("Error");
    }
}

function showErr() {
    alert("Geolocation is not supported by this browser.");
    }

    function showPosition(position) {
      lat =  position.coords.latitude;
      lng =  position.coords.longitude;
      console.log(lat);
      console.log(lng);
    }
  

//functions for image files



  var currentTempString; //get the current weather

if(currentTempString="clear-day"){
  $('#weatherimg').append($('<img>',{id:'Clear-Day',src:'images/SVG/Sun.svg'}))
  $("#currentweatherdescription").append("Clear");
}else if(currentTempString="clear-night"){
  $('#weatherimg').append($('<img>',{id:'Clear-Night',src:'images/SVG/Moon.svg'}))
  $("#currentweatherdescription").append("Clear");
}else if(currentTempString="rain"){
   $('#weatherimg').append($('<img>',{id:'Rain',src:'images/SVG/Umbrella.svg'}))
   $("#currentweatherdescription").append("Rain");
}else if(currentTempString="snow"){
   $('#weatherimg').append($('<img>',{id:'Snow',src:'images/SVG/Snowflake.svg'}))
   $("#currentweatherdescription").append("Snow");
}else if(currentTempString="sleet"){
   $('#weatherimg').append($('<img>',{id:'Sleet',src:'images/SVG/Cloud-Drizzle.svg'}))
   $("#currentweatherdescription").append("Sleet");
}else if(currentTempString="wind"){
    $('#weatherimg').append($('<img>',{id:'Wind',src:'images/SVG/Wind.svg'}))
    $("#currentweatherdescription").append("Wind");
}else if(currentTempString="fog"){
   $('#weatherimg').append($('<img>',{id:'Fog',src:'images/SVG/Fog.svg'}))
   $("#currentweatherdescription").append("Fog");
}else if(currentTempString="cloudy"){
  $('#weatherimg').append($('<img>',{id:'Cloud',src:'images/SVG/Cloud.svg'}))
  $("#currentweatherdescription").append("Cloud");
}else if(currentTempString="partly-cloudy-day"){
   $('#weatherimg').append($('<img>',{id:'Cloud-Sun',src:'images/SVG/Cloud-Sun.svg'}))
   $("#currentweatherdescription").append("Sun and Clouds");
}else if(currentTempString="partly-cloudy-night"){
  $('#weatherimg').append($('<img>',{id:'Cloud-Moon',src:'images/SVG/Cloud-Moon.svg'}))
  $("#currentweatherdescription").append("Cloudy");
}else{
 $('#weatherimg').append($('<img>',{id:'Sun-Low',src:'images/SVG/Sun-Low.svg'}))
 $("#currentweatherdescription").append("Calm");
}//els end





});