     $(document).one('pagecreate',function(){

     	var restname=new Array();
	var restcity= new Array();
	var restwebsite=new Array();
	var restphone=new Array();
	var restimage=new Array();
	var restlatitude=new Array();
	var restlongitude=new Array();
	var lat;
	var long;

	var thiscity;
	var thisphone;
	var thiswebsite;
	var i;
	var thisimg;

	var counter=0;



 $.getJSON('restaurant.json') //read data from json file
	.done(function (data) { //pass in data as a parameter


	$.each(data, function(index, value) { //this passes in data as a parameter and for each data, we call the function

	var collapsibleHeader = $("<h3></h3>").text(value.name);
	thiscity = $("<p></p>").text(value.city).attr('id',counter);
	thiswebsite = $("<a></a>").attr('href',value.website).text(value.website).attr("target", "_blank").attr('id',counter);
	//target blank opens it in new tab
	thisphone = $("<p></p>").text(value.phone).attr('id',counter);
	i=value.image;
	thisimg = $("<img>").attr('src',i).css({'width' : '150px' , 'height' : '150px'});//change height and width of default img
	
	restname.push(data[counter].name);
	restcity.push(data[counter].city);
	restphone.push(data[counter].phone);
	restwebsite.push(data[counter].website);
	restlatitude.push(data[counter].latitude);
	restlongitude.push(data[counter].longitude);

	var div = $('<div data-role="collapsible" id="list"></div>').append(collapsibleHeader).append(thiscity).append(thiswebsite).append(thisphone).append(thisimg);
	$("#displaycollapsible").append($(div).collapsible()); 
	counter++;
}); 
});

	function html5_storage_support() {
  		//check to see if this browser support local storage: return true if so, false if not
  		try {
  			return 'localStorage' in window && window['localStorage'] !== null;
  		} catch (e) {//catch exception
  			return false;
  		}
  	}

  	function setlocalStorage(index){
  		
  		localStorage.setItem("restname",restname[index]);
  		localStorage.setItem("city",restcity[index]);
  		localStorage.setItem("website",restwebsite[index]);
  		localStorage.setItem("phone",restphone[index]);
  		localStorage.setItem("lat",restlatitude[index]);
  		localStorage.setItem("long",restlongitude[index]);
  		lat=localStorage.getItem("lat");
  		long=localStorage.getItem("long"); 
  		getLocation();

  	}


  	$("#homebutton").click(function () {
  		$.mobile.changePage('#homepage');
  	})

  	$("#aubonpainbutton").click(function () {
  		setlocalStorage(0);
  		$.mobile.changePage('#googlemappage');
  	})

  	$("#lazeezbutton").click(function () {
  		setlocalStorage(1);
  		$.mobile.changePage('#googlemappage');
  	})

  	$("#jjsbutton").click(function () {
  		setlocalStorage(2);
  		$.mobile.changePage('#googlemappage');
  	})

  	$("#tasteofpunjabbutton").click(function () {
  		setlocalStorage(3);
  		$.mobile.changePage('#googlemappage');
  	})


  	 function showPosition(position) {

  	 	//if else statements to hardcode location, case 1 is cambridge

  	 	if (localStorage.getItem("restname")==="Au Bon Pain"){
  	 		 var mapProp = {
			center: new google.maps.LatLng(42.370351, -71.113588),
			zoom:15
		};
		var map = new google.maps.Map($('#map_canvas').get(0),mapProp);
		

		var marker=new google.maps.Marker({
		      
			position:new google.maps.LatLng(42.370351, -71.113588)
	

		});
		marker.setMap(map);
  	 	}else if(localStorage.getItem("restname")==="JJ Japanese and Thai"){

  	 			 var mapProp = {
			center: new google.maps.LatLng(43.597813, -79.735611),
			zoom:15
		};
		var map = new google.maps.Map($('#map_canvas').get(0),mapProp);
		

		var marker=new google.maps.Marker({
		      
			position:new google.maps.LatLng(43.597813, -79.735611)
	

		});
		marker.setMap(map);

  	 	}else if(localStorage.getItem("restname")==="Lazeez Shawarma"){

  	 		 var mapProp = {
			center: new google.maps.LatLng(43.599658, -79.712966),
			zoom:15
		};
		var map = new google.maps.Map($('#map_canvas').get(0),mapProp);
		

		var marker=new google.maps.Marker({
		      
			position:new google.maps.LatLng(43.599658, -79.712966)
	

		});
		marker.setMap(map);

  	 	}else if(localStorage.getItem("restname")==="Taste Of Punjab"){

  	 		 var mapProp = {
			center: new google.maps.LatLng(43.692755, -79.697099),
			zoom:15
		};
		var map = new google.maps.Map($('#map_canvas').get(0),mapProp);
		

		var marker=new google.maps.Marker({
		      
			position:new google.maps.LatLng(43.692755, -79.697099)
	

		});
		marker.setMap(map);

  	 	}else{

  	 		//default loc

  	 		 var mapProp = {
			center: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
			zoom:15
		};
		var map = new google.maps.Map($('#map_canvas').get(0),mapProp);
		

		var marker=new google.maps.Marker({
		      
			position:new google.maps.LatLng(position.coords.latitude, position.coords.latitude)
	

		});
		marker.setMap(map);



  	 	}

       
	
    }//end function 

function showErr() {
	alert("Geolocation is not supported by this browser.");
	}




  	   function getLocation() {
   
  if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showErr);
    }else{
    	console.log("Error");
    }

}


  $(document).on('pagecreate','#googlemappage',function(){  //specific event handler for google map page

if (localStorage.name){

   	getLocation();

  
  		var rest_name=localStorage.getItem("restname")+('<br>');
  		var rest_city=localStorage.getItem("city")+('<br>');
  		var rest_site=localStorage.getItem("website");
  		rest_site = $("<a></a>").attr('href',localStorage.getItem("website")).text(localStorage.getItem("website")).attr("target", "_blank");
  		var rest_phone=('<br>')+localStorage.getItem("phone")+('<br>');


   	$("#showinfo").append(rest_name).append(rest_city).append(rest_site).append(rest_phone);
  
    if(!localStorage.name) {
    	alert('Please select a restaurant');
    }else{
    $('<a></a>').attr('href','#restaurantselectionpage').text('Please choose a restaurant').appendTo("#error");

    }
	

}


 });//end local page create for googlemap pg

        });//end global page create


